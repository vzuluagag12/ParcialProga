public interface Forma {
    void dibujar();
}
