public class Circulo implements Forma {
    @Override
    public void dibujar() {
        System.out.println("Círculo dibujado");
    }
}