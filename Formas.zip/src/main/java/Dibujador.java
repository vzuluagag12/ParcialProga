public class Dibujador {
    public void dibujarForma(Forma forma) {
        forma.dibujar();
    }
}