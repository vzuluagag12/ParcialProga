public class Triangulo implements Forma {
    @Override
    public void dibujar() {
        System.out.println("Triángulo dibujado");
    }
}